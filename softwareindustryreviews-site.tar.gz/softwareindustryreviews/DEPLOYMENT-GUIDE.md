# How to Deploy softwareindustryreviews.com — Step-by-Step Guide

This guide assumes zero technical experience. Follow each step exactly.

---

## What You're Deploying

A complete, multi-page website with:
- Homepage (index.html)
- CRM Rankings listicle page (pages/crm-rankings.html)  
- Pricing page with Stripe integration (pages/pricing.html)
- Research/blog page (pages/research.html)
- Shared CSS stylesheet (css/style.css)

---

## Step 1: Create Free Accounts (10 minutes)

### 1a. Create a GitHub account
1. Go to https://github.com
2. Click "Sign up" and create a free account
3. Verify your email

### 1b. Create a Vercel account
1. Go to https://vercel.com
2. Click "Sign Up"
3. Choose "Continue with GitHub" (this connects them automatically)
4. Authorize the connection

### 1c. Create a Stripe account (for payments)
1. Go to https://stripe.com
2. Click "Start now" and create an account
3. You don't need to fully activate it yet — we'll set up payment links later

---

## Step 2: Upload Your Site to GitHub (15 minutes)

### Option A: Using GitHub's web interface (easiest, no terminal needed)

1. Go to https://github.com and log in
2. Click the green "New" button (top left) to create a new repository
3. Name it: `softwareindustryreviews`
4. Make sure "Public" is selected
5. Check "Add a README file"
6. Click "Create repository"

Now upload the files:

7. In your new repository, click "Add file" → "Upload files"
8. Drag and drop the `index.html` file from the downloaded project folder
9. Click "Commit changes"

10. Click "Add file" → "Create new file"
11. Type `css/style.css` as the filename (this creates the css folder automatically)
12. Paste the contents of the style.css file
13. Click "Commit changes"

14. Repeat for each file in the `pages/` folder:
    - Click "Add file" → "Create new file"
    - Type `pages/pricing.html` as the filename
    - Paste the contents
    - Click "Commit changes"
    - Do the same for `pages/crm-rankings.html` and `pages/research.html`

### Option B: Using GitHub Desktop (slightly easier for multiple files)

1. Download GitHub Desktop: https://desktop.github.com
2. Sign in with your GitHub account
3. Click "Create a New Repository"
4. Name it `softwareindustryreviews`
5. Choose a local folder on your computer
6. Click "Create Repository"
7. Copy ALL the project files into that folder (keeping the folder structure: index.html, css/, pages/)
8. In GitHub Desktop, you'll see all the files listed as changes
9. Type "Initial commit" in the summary box
10. Click "Commit to main"
11. Click "Publish repository" (top bar)

---

## Step 3: Deploy to Vercel (5 minutes)

1. Go to https://vercel.com/dashboard
2. Click "Add New..." → "Project"
3. You'll see your GitHub repositories listed
4. Click "Import" next to `softwareindustryreviews`
5. Leave all settings as default
6. Click "Deploy"
7. Wait 30-60 seconds — Vercel will build and deploy your site
8. You'll see a success screen with a URL like `softwareindustryreviews.vercel.app`
9. Click it — your site is LIVE!

---

## Step 4: Connect Your Domain (10 minutes)

1. In Vercel, go to your project → Settings → Domains
2. Type `softwareindustryreviews.com` and click "Add"
3. Vercel will show you DNS settings you need to configure

### If your domain is on GoDaddy:
1. Log into GoDaddy → My Products → DNS
2. Find the "CNAME" records section
3. Add a CNAME record: Name = `www`, Value = `cname.vercel-dns.com`
4. Find the "A" records section  
5. Change the A record to point to: `76.76.21.21`
6. Save changes
7. Wait 10-30 minutes for DNS to propagate

### If your domain is on Namecheap:
1. Log into Namecheap → Domain List → Manage
2. Go to Advanced DNS
3. Add A Record: Host = `@`, Value = `76.76.21.21`
4. Add CNAME Record: Host = `www`, Value = `cname.vercel-dns.com`
5. Save changes

### If your domain is elsewhere:
The process is similar — you need to point your domain's A record to `76.76.21.21` and add a CNAME for `www` pointing to `cname.vercel-dns.com`. Your registrar's support docs will have specific instructions.

---

## Step 5: Set Up Stripe Payment Links (15 minutes)

This is how you monetize WITHOUT building any payment code.

1. Log into Stripe Dashboard → https://dashboard.stripe.com
2. Click "Products" in the left sidebar
3. Click "+ Add product"

### Create 4 products:

**Product 1: Claimed Profile**
- Name: "Claimed Profile — Monthly"
- Price: $99.00 / month (recurring)
- Click "Save product"
- Then create another price on the same product: $999.00 / year (recurring)

**Product 2: Enhanced Listing**
- Name: "Enhanced Listing — Monthly"  
- Price: $299.00 / month (recurring)
- Add annual price: $2,999.00 / year

**Product 3: Featured Partner**
- Name: "Featured Partner — Monthly"
- Price: $699.00 / month (recurring)
- Add annual price: $6,999.00 / year

**Product 4: Sponsored Content**
- Name: "Sponsored Content Package"
- Price: $2,500.00 (one-time)

### Create Payment Links:

4. For each product, go to the product page in Stripe
5. Click "Create payment link"
6. Configure the checkout page (add your logo, adjust settings)
7. Click "Create link"
8. Copy the payment link URL (looks like `https://buy.stripe.com/abc123`)

### Add links to your website:

9. Open `pages/pricing.html` in a text editor
10. Find the 4 lines that say `href="#stripe-claimed-profile-link"` (and similar)
11. Replace each `#stripe-...` with your actual Stripe payment link URL
12. Save the file
13. Re-upload to GitHub (the site will auto-update on Vercel)

---

## Step 6: Repeat for Other Domains

To deploy a second site (e.g., `techindustryreviews.com`):

1. Duplicate the project folder on your computer
2. Change the branding (company name, colors, categories) in the HTML files
3. Create a new GitHub repository for it
4. Import it as a new project in Vercel
5. Connect the new domain

Each Vercel project gets its own deployment. The free tier supports plenty of sites.

---

## How to Update Content

### Adding a new listicle:
1. Copy an existing page (like `crm-rankings.html`)
2. Rename it (e.g., `project-management-rankings.html`)
3. Edit the content — change the title, companies, scores, etc.
4. Upload to GitHub → site auto-updates

### Editing existing content:
1. Go to your GitHub repository
2. Click on the file you want to edit
3. Click the pencil icon (edit)
4. Make your changes
5. Click "Commit changes" → site auto-updates in ~30 seconds

---

## Troubleshooting

**Site not loading after domain setup?**
DNS changes can take up to 48 hours. Usually it's 10-30 minutes. Try clearing your browser cache.

**Changes not showing up?**
Vercel auto-deploys when you push to GitHub. Check the Vercel dashboard to see if the deployment succeeded. Try a hard refresh (Ctrl+Shift+R or Cmd+Shift+R).

**Stripe links not working?**
Make sure you've replaced the placeholder `#stripe-...` links with your actual Stripe payment link URLs. The links should start with `https://buy.stripe.com/`.

**Need help?**
Come back to this Claude conversation and ask — I can troubleshoot any issues and help you build additional pages and content.
